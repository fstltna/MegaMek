Directories named "unsupported" (and all their sub-directories) are
ignored when MegaMek loads units on startup.

This makes them a good place for official units that have technology
that is not yet supported by MegaMek.  You probably don't want to
place units that are "mostly supported" in here though.  For example,
if you have a unit that has an unsupported secondary weapon system
or electronics system, MegaMek will be able to load everything else and
the unit will be playable.  The unsupported equipment won't be able to
be used.


